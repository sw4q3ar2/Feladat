import math
print(
    """
    A program  olvasson be a konzolról egy valós számot! A program számítsa ki a szám abszolút értékét,
     és írja ki az eredményeket a konzolra! A számításhoz a math.fabs() függvény helyett elágazást használjon!
    """
)

#Eredeti:
#szam=float(input("Kérem adjon meg egy valós számot!"))
#abszolutErtek= math.fabs(szam)
#print("|",szam,"|=",abszolutErtek)

#Elágazásos
szam=float(input("Kérem adjon meg egy valós számot!"))
if(szam<0):
    abszolutErtek=(-1)*szam
else:
    abszolutErtek=szam
print("|",szam,"|=",abszolutErtek)