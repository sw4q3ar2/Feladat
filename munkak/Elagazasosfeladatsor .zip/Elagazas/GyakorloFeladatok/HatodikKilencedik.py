print(
    """
    6. feladat – Szögtípus
    A program  kérjen be a konzolról egy valós számot! Ha ez a szám 0 és 360 közé esik,
    akkor legyen egy szög mértéke (pl. 60 fok), egyébként a program adjon hibaüzenetet!
    Ha lehet, a program írja ki a szög mértéke alapján a szög típusát (pl.: 60 -> hegyesszög)!

    """
)
#http://www.altsuli.hu/matf/keretszogtip.html

szam=int(input("Kérem adjon meg egy egész számot 0 és 360 között!"))
if szam==0:
    print("Nullszög.")
elif(szam>0 and szam<90):
    print("Hegyesszög.")
elif(szam==90):
    print("Derékszög")
elif(szam>90 and szam<180):
    print("Tompaszög.")
elif(szam==180):
    print("Egyenesszög.")
elif(szam>180 and szam<360):
    print("Homorú szög.")
elif(szam==360):
    print("Teljes szög.")
else:
    print("HIBA: A megadott érték nem 0 és 360 közötti!")