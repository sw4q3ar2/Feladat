import math
print(
    """
    A program számítsa ki egy beolvasott valós szám négyzetgyökét! A program adjon hibaüzenetet,
    ha a felhasználó negatív számból akar gyököt vonni!
    """
)

szam=int(input("Kérem adjon meg egy pozitív egész számot!"))
if(szam<0):
    print("HIBA: Nem pozitív a megadott érték!")
else:
    eredmeny=math.sqrt(szam)
    print("A ", szam, "Négyzetgyöke: ", eredmeny)