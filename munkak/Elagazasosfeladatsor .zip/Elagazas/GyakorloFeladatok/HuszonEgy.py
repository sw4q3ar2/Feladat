print(
    """
    21. feladat – Legkösebb3Közül
    A program döntse el, hogy 3 beolvasott valós szám közül melyik a legkisebb! A döntés eredményét
    a program írja ki a konzolra!

    """
)

szam1=float(input("Kérem adjon meg egy egész számot!"))
szam2=float(input("Kérem adjon meg egy egész számot!"))
szam3=float(input("Kérem adjon meg egy egész számot!"))

if(szam1<szam2 and szam1<szam3):
    print(szam1, "a legkisebb szám.")
if(szam3<szam2 and szam3<szam1):
    print(szam3, "a legkisebb szám.")
if(szam2<szam1 and szam2<szam3):
    print(szam2, "a legkisebb szám.")