print(
    """
    23. feladat – Osztható15tel
    A program olvasson be egy legalább háromjegyű pozitív egész számot! Ha kisebbet írnak be,
    akkor írja ki, hogy nem megfelelő, egyébként vizsgálja meg, hogy a szám osztható-e 15-tel
    (3-mak, 5-tel is),. és írja ki a megfelelő szöveget!

    """
)

szam=float(input("Kérem adjon meg egy háromjegyű pozitív egész számot!"))
if szam<100 or szam>999:
    print("Nem megfelelő!")
else:
    if(szam%3==0 and szam%5==0):
        print("A szám osztható 15-el!")
    else:
        print("A szám nem osztható 15-el.!")