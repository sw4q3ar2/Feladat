print(
    """
    22. feladat – ElsőfokúEgyenlet2
    A program oldja meg az a*x+b=0 alakú egyenletet! Kérje be a konzolról az a és b valós típusú
    változókat! Ha az a értéke nem nulla, akkor a program számítsa ki és írja ki a megoldást
    (x=-b/a) a konzolra, egyébként írjon ki hibaüzenetet!
    """
)

a=float(input("a: Kérem adjon meg egy egész számot!"))
b=float(input("b: Kérem adjon meg egy egész számot!"))

if(a!=0):
    eredmeny=(-1)*b/a
    print("x=-",b,"/",a,"=", eredmeny)
else:
    print("HIBA: a értéke nem lehet nulla!")