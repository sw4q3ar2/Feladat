print(
    """
    24. feladat – KarakterTípus
    A program döntse el, hogy egy beolvasott karakter kisbetű, nagybetű, számjegy vagy egyéb karakter!
    """
)

try:
    karakter=input("Adj meg egy értéket!")
    szkarakter=int(karakter)
    print("Az érték szám!")
except ValueError:
    #szöveg
    if karakter.islower():
        print("kisbetűs")
    elif karakter.isupper():
        print("nagybetűs")
    else:
        print("Egyéb karakter!")