print(
    """
    5. feladat – HónapNév
    A program  olvasson be a konzolról egy egész számot! Ha a szám 1 és 12 közötti, akkor
    legyen a beolvasott szám egy hónap sorszáma! A program írja ki a konzolra a sorszámmal megadott
    hónap nevét! Hiba esetén legyen hibaüzenet!

    """
)
szam=int(input("Kérem adjon meg egy egész számot 1 és 12 között!"))
if(szam==1):
    print("január")
elif(szam==2):
    print("február")
elif(szam==3):
    print("március")
elif(szam==4):
    print("április")
elif(szam==5):
    print("május")
elif(szam==6):
    print("június")
elif(szam==7):
    print("július")
elif(szam==8):
    print("agusztus")
elif(szam==9):
    print("szeptember")
elif(szam==10):
    print("október")
elif(szam==11):
    print("november")
elif(szam==12):
    print("december")
else:
    print("HIBA: a szám nem 1 és 12 közötti érték!")


