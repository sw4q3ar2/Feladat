import math
print(
    """
    13. feladat – Kör
    A program olvassa be a konzolról egy kör sugarát! Ha a sugár nem pozitív, akkor a program írja ki
    konzolra, hogy "Hiba: a kör sugara nem pozitív!"; egyébként a program számítsa ki és írja ki
    a kör kerületét, területét a konzolra!

    """
)

#https://hu.wikipedia.org/wiki/K%C3%B6r_(geometria)

sugar=float(input("Add meg a kör sugarát!"))

if(sugar<0):
    print("Hiba: a kör sugara nem pozitív!")
else:
    kerulet=2*sugar*math.pi
    terulet=math.pow(sugar,2)*math.pi
    print("Kerület: ",kerulet, " terület: ", terulet,".")
