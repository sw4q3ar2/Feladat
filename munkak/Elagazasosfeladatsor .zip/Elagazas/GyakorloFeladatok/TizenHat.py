import math
print(
    """
    16. feladat – Háromszög1
    A program olvassa be a konzolról egy egyenlő oldalú háromszög oldalát.
    A program számítsa ki és írja ki a háromszög kerületét, területét!
    Hiba esetén a program írja ki a konzolra, hogy "Hiba: a háromszög oldala nem pozitív!"!

    """
)
#https://hu.wikipedia.org/wiki/H%C3%A1romsz%C3%B6g

oldal1=float(input("Add meg az oldal hosszát!"))
if(oldal1>0):
    t=1/4*math.sqrt(3*math.pow(oldal1,2))
    k=3*oldal1
    print("A háromszög kerülete: ",k, "területe: ",t,".")

else:
    print("Hiba: a háromszög oldala nem pozitív!")