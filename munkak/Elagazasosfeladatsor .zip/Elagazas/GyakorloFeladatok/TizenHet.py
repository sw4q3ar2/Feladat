print(
    """
    17. feladat – KétjegyűSzám
    A program döntse el és írja ki, hogy egy beolvasott egész szám kétjegyű-e!

    """
)

szam=int(input("Kérem adjon meg egy egész számot!"))
if((szam>=10 and szam<=99) or (szam>=-99 and szam<=-10)):
    print("A szám kétjegyű.")
else:
    print("A szám nem kétjegyű.")