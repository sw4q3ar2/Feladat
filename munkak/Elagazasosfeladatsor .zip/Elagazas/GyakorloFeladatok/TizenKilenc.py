print(
    """
    19. feladat – Háromszög2
    A program olvasson be három valós számot! Tegyük fel, hogy ezek egy-egy szakasz hosszát
    fejezik ki megegyező mértékegységben! A program döntse el, és írja ki, hogy a három szakaszból
    szerkeszthető-e háromszög vagy sem!

    """
)
#https://hu.wikipedia.org/wiki/H%C3%A1romsz%C3%B6g-egyenl%C5%91tlens%C3%A9g

szakasz1=float(input("Add meg a szakasz hosszát!"))
szakasz2=float(input("Add meg a szakasz hosszát!"))
szakasz3=float(input("Add meg a szakasz hosszát!"))

if(szakasz1>0 and szakasz2>0 and szakasz3>0):
    if(szakasz1+szakasz2>szakasz3 and szakasz3+szakasz2>szakasz1 and szakasz1+szakasz3>szakasz2):
        print("Szerkeszthető háromszög!")
    else:
        print("Nem szerkeszthető háromszög!")
else:
    print("HIBA: A három szög oldalai nem 0-nál nagyobb értékek!")