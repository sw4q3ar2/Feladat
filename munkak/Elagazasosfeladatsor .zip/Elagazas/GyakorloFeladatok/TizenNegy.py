import math
print(
    """
    14. feladat – Kocka
    A program olvasson be a konzolról egy egész számot! Ha a szám pozitív,
    akkor legyen a beolvasott szám egy kocka élének hossza. A program számítsa
    ki és írja ki a kocka felszínét, térfogatát a konzolra! Ha a szám nem pozitív,
    akkor a program írja ki konzolra, hogy "Hiba: a kocka élének hossza nem pozitív!"!

    """
)
#https://hu.wikipedia.org/wiki/Kocka

oldal=float(input("Add meg az oldal hosszát!"))
if(oldal>0):
    a=6*math.pow(oldal,2)
    v=math.pow(oldal,3)
    print("A kocka felszíne: ",a, "térfogata: ", v,".")

else:
    print("Hiba: a kocka élének hossza nem pozitív!")