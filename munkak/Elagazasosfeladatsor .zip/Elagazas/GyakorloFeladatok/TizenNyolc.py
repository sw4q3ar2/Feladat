print(
    """
    18. feladat – RómaiSzámjegyek
    A program olvasson be egy egész számot! Ha a szám 0-nál nagyobb és 10-nél kisebb,
    akkor a program írja ki a számot római számként; egyébként írja ki,
    hogy "Túl kicsi!" vagy "Túl nagy szám!"!

    """
)


szam=int(input("Kérem adjon meg egy számot 0 és 10 között!"))
if szam<0:
    print("Túl kicsi!")
elif szam>10:
    print("Túl nagy.")
else:
    if(szam==0):
        print("0")
    elif(szam==1):
        print("I")
    elif (szam == 2):
        print("II")
    elif (szam == 3):
        print("III")
    elif (szam == 4):
        print("IV")
    elif (szam == 5):
        print("V")
    elif (szam == 6):
        print("VI")
    elif (szam == 7):
        print("VII")
    elif (szam == 8):
        print("VIII")
    elif (szam == 9):
        print("IX")
    else:
        print("X")