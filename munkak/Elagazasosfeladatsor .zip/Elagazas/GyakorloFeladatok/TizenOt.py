import math
print(
    """
    15. feladat – Téglalap1
    A program olvasson be a konzolról két valós számot! Ha mindkét szám pozitív, akkor legyenek
    a beolvasott számok egy téglalap oldalai. A program számítsa ki a téglalap kerületét, területét,
    és írja ki két tizedesre kerekítve az eredményeket a konzolra! Hiba esetén írja ki:
    "Hiba: a téglalap oldalai nem pozitívak!"!
    """
)
#https://hu.wikipedia.org/wiki/T%C3%A9glalap

oldal1=float(input("Add meg az oldal hosszát!"))
oldal2=float(input("Add meg a másik oldal hosszát!"))
if(oldal1>0 and oldal2>0):
    t=oldal1*oldal2
    k=2*(oldal1*oldal2)
    print("A téglalap kerülete: {:.2f}".format(k), "területe: {:.2f}".format(t),".")

else:
    print("Hiba: a téglalap oldalai nem pozitívak!")