print(
    """
    11. feladat – Húsvét A program kérjen be egy évszámot a felhasználótól!
    Ha ez 1900 és 2099 közé esik, akkor a program írja ki, hogy az adott évben melyik
    napra esik húsvét vasárnap! A kiszámítás algoritmusát megtalálja a Wikipedia-ban Gauss módszer néven.

    """
)
#A Húsvét egy mozgó ünnep, tehát minden évben más napokra esik. A Níceai zsinaton tettek kísérletet először arra, hogy meghatározzák az ünnep kiszámításának helyes időpontját.
#Ekkor olyan döntés született, hogy Húsvét legyen minden évben a tavaszi nap-éj egyenlőség utáni első holdtöltét követő vasárnap. Ez azonban sok bonyodalomhoz vezetett. Végül a katolikus egyház 1581-ben egy kánonba foglalva határozta meg a Húsvét kiszámításának módját, melyhez azóta is ragaszkodnak.

#https://hu.wikipedia.org/wiki/H%C3%BAsv%C3%A9tsz%C3%A1m%C3%ADt%C3%A1s

szam=int(input("Adj meg egy egész számot 1900 és 2099 között!"))
a= szam%19
b=szam%4
c=szam%7

m=24
n=5

d=(19*a+m)%30
e=(2*b+4*c+6*d+n)%7

if(d+e<10):
    nap=d+e+22
    print("március ", nap,".")
else:
    nap=d+e-9
    if(nap==26):
        print("április 19")
    elif(nap==25):
        print("április 18")
    else:
        print("április ", nap,".")

#ellenörzés: https://hu.wikipedia.org/wiki/H%C3%BAsv%C3%A9t
