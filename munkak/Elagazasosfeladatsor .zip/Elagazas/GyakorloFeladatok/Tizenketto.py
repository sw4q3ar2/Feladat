print(
    """
    12. feladat – KisebbNagyobbEgyenlőReláció
    A program két beolvasott számot összehasonlítva írja közéjük a megfelelő relációs jelet (<, >, =)!
    """
)
szam1=float(input("Adj meg egy  számot!"))
szam2=float(input("Adj meg egy másik  számot!"))

if(szam1==szam2):
    print(szam1,"=", szam2)
elif(szam1<szam2):
    print(szam1,"<", szam2)
else:
    print(szam1,">", szam2)
