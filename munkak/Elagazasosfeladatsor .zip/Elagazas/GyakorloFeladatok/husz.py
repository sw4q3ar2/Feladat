print(
    """
    20. feladat – Magasság
    A program olvasson be a konzolról egy egész számot! Ha a szám pozitív, akkor legyen a beolvasott szám
    egy méterben kifejezett tengerszint feletti magasság. Ha a magasság 200 m alatti, akkor "Alföld";
    egyébként, ha 500 ,m alatti, akkor "Dombság"; egyébként, ha 1500 m alatti, akkor "Középhegység";
    egyébként "Hegység"-ről van szó! A program írja ki a megfelelő szöveget a konzolra!

    """
)

szam=int(input("Kérem adjon meg egy egész számot!"))
if(szam>0):
    if szam<200:
        print("Alföld")
    elif szam<500:
        print("Dombság")
    elif szam<1500:
        print("Középhegység")
    else:
        print("Hegység")
else:
    print("Tengerszint alatti érték!")