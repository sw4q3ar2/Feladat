print(
    """
    2.	MegelőzőKövetkezőSzám: A program kérjen be a konzolról egy egész számot! Ha a szám egyjegyű,
    akkor a program írja ki a konzolra a számot megelőző és követő egész számot,
    egyébként ne írjon ki semmit!
    """
)

szam=int(input("Kérem adjon meg egy egyjegyű számot!"))
if(szam>-10 and szam<10):
    print("Megelöző: ", szam-1, ", következő: ", szam+1)
