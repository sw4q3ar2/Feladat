print(
    """
    8. feladat: Az K és az k betűt a cenzúra betiltotta. Írd ki a szöveget úgy,
    hogy helyettük csillagot írsz! A végére írd ki, hogy hány K és hány
    k betűt helyettesítettél csillaggal!
    """
)

forrasFajl=open('Fájlok/hatodik.txt', 'r', encoding='utf-8')

dbK=0
dbk=0

while True:
    betu=forrasFajl.read(1)
    if betu:
        if betu=='k':
            print("*", end="")
            dbk+=1
        elif betu == 'K':
            print("*", end="")
            dbK+=1
        else:
            print(betu, end="")
    else:
        print("")
        break
forrasFajl.close()
print("A k betűk száma: {}, és a K betűk száma {}.".format(dbk, dbK))

