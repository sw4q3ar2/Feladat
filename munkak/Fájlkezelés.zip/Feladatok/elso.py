print(
    """
    1. feladat: Olvasd be a fájlt, és írd ki a tartalmát egy sorba,
    úgy, hogy nem tárolod el a szöveget, hanem minden sort azonnal kiírsz!
    """
)
forrasFajl=open('Fájlok/MegMindig.txt', 'r', encoding='utf-8')

for sor in forrasFajl:
   print(sor.strip(), end=' ')

forrasFajl.close()
