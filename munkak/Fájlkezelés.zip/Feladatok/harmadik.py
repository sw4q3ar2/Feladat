print(
    """
    3. feladat: 	Olvasd be a fájlt, tárold a sorokat listában,
    majd írd ki a lista tartalmát egy sorként egy másik fájlba! (Fájlok/kiharom.txt)
    """
)
lista=[]

#fájl kezelés, soronkénti feldolgozás
with open('Fájlok/MegMindig.txt', 'r', encoding='utf-8') as forrasFajl:
    for sor in forrasFajl:
        tisztitott = sor.strip()
        lista.append(tisztitott)

# kiiratás
with open('Fájlok/kiharom.txt', 'w', encoding='utf-8') as kiFajl:
    for sor in lista:
        print(sor, end=" ", file=kiFajl)

#kiiratás második megoldás
#with open('Fájlok/kiharom.txt', 'w', encoding='utf-8') as kiFajl:
#    print(' '.join(lista), file=kiFajl)