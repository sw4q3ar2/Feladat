print(
    """
    7. feladat: 	Olvasd be a fájlt és írd ki a sorait fordított sorrendben,
    a képernyőre csakúgy, mint egy fájlba!
    """
)

lista=[]
forrasFajl=open('Fájlok/hatodik.txt', 'r', encoding='utf-8')
kiFajl=open('Fájlok/kiHetedik.txt', 'w', encoding='utf-8')

for sor in forrasFajl:
   lista.append(sor.strip())

#első megoldás: lista végétől haladunk az eleje fele vissza: 8 7 6 5 4 3 2 1 0
#for i in range(len(lista)-1,-1,-1):
#    print(lista[i])
#    print(lista[i], file=kiFajl)

#második megoldás: lista - indexétől haladunk: -8 -7 -6 -5 -4 -3 -2 -1
#for i in range(-1,len(lista)*-1-1,-1):
#    print(lista[i])
#    print(lista[i], file=kiFajl)

#harmadik megoldás: megfordítja a reevers függvény a listát
for sor in reversed(lista):
    print(sor)
    print(sor, file=kiFajl)


forrasFajl.close()
kiFajl.close()