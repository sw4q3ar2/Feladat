
#a kiíró eljárásunk dönti el, hogy a képernyőre ír-e vagy a fájlba attól függően, hoyg miylen paramétert kap
def kiir(lista, hova):

    if hova=='sys.stdout':
        # konzolra
        print('\n'.join(lista))
    else:
        #fájlba
        kiFajl = open(hova, 'w', encoding='utf-8')
        print('\n'.join(lista), file=kiFajl)
        kiFajl.close()

#főprogrami rész
print(
    """
    7. feladat: 	Olvasd be a fájlt és írd ki a sorait fordított sorrendben,
    a képernyőre csakúgy, mint egy fájlba!
    """
)
#beolvasás fájlból listába
lista=[]
forrasFajl=open('Fájlok/hatodik.txt', 'r', encoding='utf-8')


for sor in forrasFajl:
   lista.append(sor.strip())

#harmadik megoldás: megfordítja a revers függvény a listát
kiir(reversed(lista), 'sys.stdout')
kiir(reversed(lista), 'Fájlok/kiHetedikP.txt')

forrasFajl.close()
