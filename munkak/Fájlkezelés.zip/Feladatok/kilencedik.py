def teszt(adat):
    magánhangzók = ['a', 'á', 'e', 'é', 'i', 'í', 'o', 'ó', 'ö', 'ő', 'u', 'ú', 'ü', 'ű']
    # print(magánhangzók)
    db=0
    for i in range(0,len(adat)-3,1):
        if (adat[i] in magánhangzók) and (adat[i+1] not in magánhangzók) and (adat[i+2] not in magánhangzók):
            #print(adat[i], end=" ")
            db+=1
    return db

print(
    """
    9. feladat: Olvasd be soronként a fájlt, és egy függvénnyel
    állapítsd meg, hogy hány olyan magánhangzó van az adott sorban,
    ami után legalább két mássalhangzó van! 
    b,Írj olyan változatot is,ami nem veszi figyelembe,
    ha a két mássalhangzó között szóközt találsz!
    """
)
i=1
forrasFajl=open('Fájlok/hatodik.txt', 'r', encoding='utf-8')
for sor in forrasFajl:
    print("magánhangzók száma: ",teszt(sor))
    i+=1

