print(
    """
    Olvasd be a fájlt, tárold a sorokat listában,
    majd írd ki a lista tartalmát egy sorban! 
    """
)
lista=[]

#fájl kezelés, soronkénti feldolgozás
with open('Fájlok/MegMindig.txt', 'r', encoding='utf-8') as forrasFajl:
    for sor in forrasFajl:
        tisztitott=sor.strip()
        lista.append(tisztitott)

#kiiratás
for szoveg in lista:
    print(szoveg, end=" ")

#kiiratás2
#print(' '.join(lista))
