print(
    """
    4. feladat: Olvasd be a fájlt, tárold a sorokat listában,
    majd írd ki a lista tartalmát így, ahogy beolvastad, soronként
    egy szóval egy másik fájlba! (Fájlok/kinegy.txt)
    """
)
lista=[]

#fájl kezelés, soronkénti feldolgozás
with open('Fájlok/MegMindig.txt', 'r', encoding='utf-8') as forrasFajl:
    for sor in forrasFajl:
        tisztitott = sor.strip()
        lista.append(tisztitott)

# kiiratás
with open('Fájlok/kinegy.txt', 'w', encoding='utf-8') as kiFajl:
    for sor in lista:
        print(sor, file=kiFajl)

#kiiratás második megoldás
#with open('Fájlok/kinegy.txt', 'w', encoding='utf-8') as kiFajl:
#    print(' \n'.join(lista), file=kiFajl)