print(
    """
    5. feladat: 	Olvasd be a fájlt, és írd ki a tartalmát egy másik fájlba,
    úgy, hogy nem tárolod el a szöveget, hanem minden sort azonnal kiírsz!
    """
)
forrasFajl=open('Fájlok/MegMindig.txt', 'r', encoding='utf-8')
kiFajl=open('Fájlok/kiOtodik.txt', 'w', encoding='utf-8')

for sor in forrasFajl:
   print(sor.strip(), file=kiFajl)
   #másik megoldás
   #print(sor, end='', file=kiFajl)

forrasFajl.close()
kiFajl.close()