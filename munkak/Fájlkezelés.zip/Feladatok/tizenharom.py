print(
    """
    12. feladat: Olvass be egy bowling állást majd számold meg,
    hogy hány ledöntött bábú van benne, ezt írd is ki a felhasználónak!
    A ledöntött bábukat a 0 jelenti.
    """
)
pont=0
lista=[]

with open('Fájlok/tizenharom.txt','w', encoding='utf-8') as kiFajl:
    with open('Fájlok/tizenketto.txt','r', encoding='utf-8') as beFajl:

        for sor in beFajl:
            for szo in sor:
                lista.append(szo)
        #print(lista)

        # első elem külön ellenőrzése
        if lista[0] == "0":
            pont += 1
        print(lista[0], end="", file=kiFajl)

        # többi elem (megelőzőség miatt 10 nem jó)
        for szamok in range(1,len(lista),1):
            print(lista[szamok], end="", file=kiFajl)
            if lista[szamok]=="0" and lista[szamok-1]!="1":
                pont+=1

    #pontok kiírása
    print("", file=kiFajl)
    print("A játékos: {} pontot szerzett.".format(pont), file=kiFajl)