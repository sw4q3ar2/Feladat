print(
    """
    10. feladat: 	Olvasd be a fájl tartalmát majd számold meg hány l betű van benne.
    """
)

db=0
with open('Fájlok/hatodik.txt', 'r', encoding='utf-8') as forrasFajl:
    while True:
        betu=forrasFajl.read(1)
        if betu:
            if betu=="l":
                db+=1
        else:
            break
print("Az l betűk szaáma", db)

