print(
    """
    1.	Kérj be tetszőleges szöveget, majd írasd ki a hosszát.
    """
)

szoveg=input("Adj meg egy szöveget!")
hossz=len(szoveg)
print("A szöveg hossza: ", hossz, "karakter")