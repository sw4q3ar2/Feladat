print(
    """
    3.	Kérj be tetszőleges szöveget,
     majd mindek karakterét cseréld nagybetűsre.
    """
)


szoveg=input("Adj meg egy szöveget!")

print(szoveg.upper())