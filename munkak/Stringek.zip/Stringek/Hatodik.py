print(
    """
    6.	Az előző programot alakítsa át úgy, hogy
    a számlálandó betűt is a felhasználó adja meg!
    """
)
#teszt mondat: "A kék madarak szállnak." eredmény:  5

#első változat
#szoveg=input("Adj meg egy mondatot!")
#db=0;
#for i in szoveg:
#    if i=="a":
#        db+=1
#print("A mondatban az a betűk száma: ", db)

#Másoik változat nagy A és kis a betűket is számol:
szoveg=input("Adj meg egy mondatot!")
betu=input("Add meg a keresendő betűt!")
kisbetu=betu.lower()
nagybetu=betu.upper()
db=0;
for i in szoveg:
    if i==kisbetu or i==nagybetu:
        db+=1
print("A mondatban az a betűk száma: ", db)
