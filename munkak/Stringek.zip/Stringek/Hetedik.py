print(
    """
        7.	Az input szövegből távolítsa el a szóközöket!
    """
)

szoveg=input("Adj meg egy mondatot!")
hossz=len(szoveg)
aszoveg=""
for i in range(hossz):
    if szoveg[i]==" ":
        aszoveg+=""
    else:
        aszoveg+=szoveg[i]
print("az átalakított szöveg: ", aszoveg)
