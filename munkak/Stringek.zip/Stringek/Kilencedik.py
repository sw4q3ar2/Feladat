print(
    """
    9.	A beolvasott mondat kisbetűit alakítsa nagybetűsre,
     a nagybetűs karaktereket pedig kisbetűsre!
    """
)

mondat=input("Adj meg egy mondatot!")
amondat=""

for i in mondat:
    if i.islower():
        amondat+=i.upper()
    elif i.isupper():
        amondat+=i.lower()
print("Az átalakított mondat: ", amondat)