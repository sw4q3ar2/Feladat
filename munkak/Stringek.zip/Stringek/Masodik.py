print(
    """
    2.	Kérj be tetszőleges szöveget, majd írasd ki úgy,
     hogy  minden karaktere egymás alatt legyen.
    """
)

szoveg=input("Adj meg egy szöveget!")

#1.megoldás
#hossz=len(szoveg)
#for i in range(hossz):
#    print(szoveg[i])

#2.megoldás
#i=0
#while i<len(szoveg):
#    print(szoveg[i])
#    i+=1

#3.megoldás
for j in szoveg:
    print(j)