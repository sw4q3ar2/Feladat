print(
    """
    4.	Kérj be tetszőleges szöveget, majd írasd ki visszafelé.
    """
)

szoveg=input("Adj meg egy szöveget!")

#1.megoldás
#hossz=len(szoveg)
#for i in range(hossz-1,-1,-1):
#    print(szoveg[i])

#2.megoldás
i=len(szoveg)-1
while i>-1:
    print(szoveg[i])
    i-=1

