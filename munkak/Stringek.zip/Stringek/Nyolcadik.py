print(
    """
    8.	Olvasson be egy mondatot és egy szót!
     Mondja meg, hogy a szó szerepel-e a mondatban!
    """
)
mondat=input("Adj meg egy mondatot!")
szo=input("Adj meg egy mondatot!")

hol_van=mondat.find(szo)
if hol_van==-1:
    print("Nincsen benne a keresett szó a mondatban.")
else:
    print("A szó szerepel a mondatban.")
