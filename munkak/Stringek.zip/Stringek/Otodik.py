print(
    """
    5.	Írjon programot, mely megszámolja, hogy az inputként érkező
     mondatban hány darab ”a” betű van!
    """
)
#teszt mondat: "A kék madarak szállnak." eredmény:  5

#első változat
#szoveg=input("Adj meg egy mondatot!")
#db=0;
#for i in szoveg:
#    if i=="a":
#        db+=1
#print("A mondatban az a betűk száma: ", db)

#Másoik változat nagy A és kis a betűket is számol:
szoveg=input("Adj meg egy mondatot!")
db=0;
for i in szoveg:
    if i=="a" or i=="A":
        db+=1
print("A mondatban az a betűk száma: ", db)
