print(
    """
    13. Írj programot ami beolvas egy nevet, és megadja a monogramját
    (a név tetszőleges számú szóból állhat, egy szóközzel elválasztva),
    valamint kezeli a dopla betűket is. ( CS,DZ,GY,LY,NY,SZ,TY,ZS)
    """
)

nev=input("Kérlek add meg a nevet!")
ntagolt=nev.split()
monogram=""
for i in ntagolt:
    monogram+=i[0]
print("Monogram: ",monogram)
