print(
    """
    12. Írj programot ami beolvas egy nevet, és megadja a monogramját
     (a név két szóból álljon, egy szóközzel elválasztva)
    """
)

nev=input("Kérlek add meg a nevet!")
ntagolt=nev.split()
monogram=ntagolt[0][0]
monogram+=ntagolt[1][0]
print("Monogram: ",monogram)
