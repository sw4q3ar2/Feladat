import string

print(
    """
    11. A beolvasott mondatról döntse el, hogy az visszafelé
    is ugyanazt jelenti-e! (Az ”Indul a görög aludni”,
    vagy a ”Géza kék az ég” visszafelé olvasva is ugyanazt jelenti.)
    Ügyeljen a mondatvégi írásjelekre, mivel azok a mondat
    elején nem szerepelnek.
    """
)

mondat=input("Kérem adja meg a vizsgálanndó mondatot!")
#szöveg kisbetűsítése
mondatk=mondat.lower()
#szóközök eltávolítása
hossz=len(mondatk)
aszoveg=""
for i in range(hossz):
    if mondatk[i]==" ":
        aszoveg+=""
    else:
        aszoveg+=mondatk[i]
#ellenörzősor
#print(aszoveg)


#írásjelek eltávolítása
irasjel_nelkuli = ""
for karakter in aszoveg:
    if karakter not in string.punctuation:
        irasjel_nelkuli += karakter
#ellenörzősor
#print( irasjel_nelkuli)

#írásjel nélküli átalakított szöveg összehasonlítása
egyezik=True
i=0
while(i<len(irasjel_nelkuli) and egyezik):
    if irasjel_nelkuli[i]!=irasjel_nelkuli[len(irasjel_nelkuli)-i-1]:
       egyezik=False
    # ellenörzősor
    #print(i, " ", aszoveg[i], " ", aszoveg[len(aszoveg) - i - 1])
    i += 1


if egyezik:
    print("A mondat visszafele is ugyanazt jelenti!")
else:
   print("A mondat visszafele nem ugyanazt jelenti!")

