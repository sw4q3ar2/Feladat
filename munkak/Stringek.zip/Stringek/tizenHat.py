print(
    """
    16. Két mondatról döntse el, hogy azonosak-e! Ha a kis és nagybetűk
     különböznek, a programnak akkor is megoldást kell adnia!
    """
)

mondat1=input("Kérlek adj meg egy mondatot!")
mondat2=input("Kérlek adj meg egy mondatot!")

#a mondatok kisbetűssé alakítása
kmondat1=mondat1.lower()
kmondat2=mondat2.lower()

#megviszgálni őket egyformák-e
i=0
egyeznek=True
while(egyeznek and i<len(kmondat1)):
    if(kmondat1[i]!=kmondat2[i]):
        egyeznek=False
    i+=1
if egyeznek:
    print("A két mondat megegyezik.")
else:
    print("A két mondat nem egyezik meg.")