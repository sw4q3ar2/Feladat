print(
    """
    17. Az inputként beolvasott szövegben cserélje ki az összes szóközt a
     # karakterre, majd az így kapott szöveget írja ki a képernyőre!
    """
)

szoveg=input("Adj meg egy mondatot!")
hossz=len(szoveg)
aszoveg=""
for i in range(hossz):
    if szoveg[i]==" ":
        aszoveg+="#"
    else:
        aszoveg+=szoveg[i]
print("az átalakított szöveg: ", aszoveg)