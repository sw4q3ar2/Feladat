print(
    """
    Írjon programot, mely megszámolja, hogy az inputként érkező mondatban
     hány darab ”h” betű van!
    """
)

mondat=input("Kérlek adj meg egy mondatot!")

db=0;
for i in mondat:
    if i=="h" or i=="H":
        db+=1
print("A mondatban lévő h betűk száma:", db)
