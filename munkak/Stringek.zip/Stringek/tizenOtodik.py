print(
    """
    15. Olvasson be egy számot egy string típusú változóba,
     majd alakítsa szám típussá!
    """
)

szam=input("Kérlek adj meg egy számot!")
#átalkítás
egesz=int(szam)
lebegopontos=float(szam)