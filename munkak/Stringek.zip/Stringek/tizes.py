print(
    """
    10. Kérj be két szót, majd döntese el a program,
     hogy ugyanazok-e?
    """
)

szo1=input("Add meg az első szót!")
szo2=input("Add meg a második szót!")
azonosak=False
if(len(szo1)==len(szo2)):
    for i in range(0,len(szo1)):
        if szo1[i]==szo2[i]:
            azonosak=True

if azonosak:
    print("A két szó megegyezik!")
else:
    print("A két szó különböző!")