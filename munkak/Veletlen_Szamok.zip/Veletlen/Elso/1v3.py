import random
import math
print(
    """
    1.	A program olvasson be a konzolról egy egész számot!
    A program döntse el, hogy a megadott szám páros
    vagy páratlan, és írja ki az eredményt a konzolra!
    a.	Ugyanezt valósítsd meg véletlen számmal is!
    b.	Csak páros számot fogadj el, és add meg a négyzetét!
    """
)

szam=random.randint(-1000,1000)
print("A generált szám:",szam)

while szam%2!=0:
    szam = random.randint(-1000, 1000)
    print("A generált szám:", szam)

#print("A szám négyzete:",szam*szam)
#print("A szám négyzete:",szam**2)
#print("A szám négyzete:",pow(szam,2))
print("A szám négyzete:",math.pow(szam,2))


#if szam%2==0:
#    print("Páros a szám.")
#else:
#    print("Páratlan a szám.")
