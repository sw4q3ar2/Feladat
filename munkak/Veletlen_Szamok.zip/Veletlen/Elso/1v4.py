import random
import math
print(
    """
    1.	A program olvasson be a konzolról egy egész számot!
    A program döntse el, hogy a megadott szám páros
    vagy páratlan, és írja ki az eredményt a konzolra!
    a.	Ugyanezt valósítsd meg véletlen számmal is!
    b.	Csak páros számot fogadj el, és add meg a négyzetét!
    c.	Alakítsd át a b programot, hogy függvényel működjön!
    """
)

#függvény
def vel():
    szam = random.randint(-1000, 1000)
    print("A generált szám:", szam)
    return szam

#szam=random.randint(-1000,1000)
#print("A generált szám:",szam)
szam1=vel()

while szam1%2!=0:
    #szam = random.randint(-1000, 1000)
    #print("A generált szám:", szam)
    szam1 = vel()

print("A szám négyzete:",math.pow(szam1,2))


#if szam%2==0:
#    print("Páros a szám.")
#else:
#    print("Páratlan a szám.")
