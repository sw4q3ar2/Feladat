import random
import math
import Elso.SAjatVeletlenGeneralo
print(
    """
    1.	A program olvasson be a konzolról egy egész számot!
    A program döntse el, hogy a megadott szám páros
    vagy páratlan, és írja ki az eredményt a konzolra!
    a.	Ugyanezt valósítsd meg véletlen számmal is!
    b.	Csak páros számot fogadj el, és add meg a négyzetét!
    c.	Alakítsd át a b programot, hogy függvényel működjön!
    d.	Külső modulból hívja meg a függvényt, a főprogram!
    """
)

#függvény
#def vel():
#    szam = random.randint(-1000, 1000)
#    print("A generált szám:", szam)
#    return szam


szam1=Elso.SAjatVeletlenGeneralo.vel()

while szam1%2!=0:
    szam1 = Elso.SAjatVeletlenGeneralo.vel()

print("A szám négyzete:",math.pow(szam1,2))


#if szam%2==0:
#    print("Páros a szám.")
#else:
#    print("Páratlan a szám.")
