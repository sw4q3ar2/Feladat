import random
#függvény
def vel():
    szam = random.randint(-1000, 1000)
    print("A generált szám:", szam)
    return szam