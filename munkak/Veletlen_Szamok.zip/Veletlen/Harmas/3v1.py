print(
    """
    3.	A program  kérjen be a konzolról egy valós számot!
    Ha ez a szám 0 és 360 közé esik, akkor legyen egy
    szög mértéke (pl. 60 fok), egyébként a program
    adjon hibaüzenetet! Ha lehet, a program írja ki a
    szög mértéke alapján a szög típusát 
    (pl.: 60 -> hegyesszög)! 
    (http://www.altsuli.hu/matf/keretszogtip.html)
    """
)

szam=float(input("Kérem adjon egy valós számot 0° és 360° között! pl.: 60"))

if szam>=0 and szam<=360:
    #szögkiiratás
    print(szam," -> ", end=" ")
    #szögtípus megállapítás
    if szam==0:
        print("nullszög.")
    elif szam>0 and szam<90:
        print("hegyes szög")
    elif szam==90:
        print("derékszög")
    elif szam>90 and szam<180:
        print("tompa szög")
    elif szam==180:
        print("egyenesszög")
    elif szam>180 and szam<360:
        print("homorú szög")
    elif szam==360:
        print("teljesszög")



else:
    print("HIBA: A megadott érték: ", szam," nem esik 0 és 360 közé!")