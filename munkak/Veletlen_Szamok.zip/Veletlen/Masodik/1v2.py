import random
print(
    """
    2.	A program  olvasson be a konzolról egy egész
    számot! Ha a szám 1 és 12 közötti, akkor
    legyen a beolvasott szám egy hónap sorszáma!
    A program írja ki a konzolra a sorszámmal
    megadott hónap nevét! Hiba (1-nél kisebb
    vagy 12-nél nagyobb szám) esetén legyen
    hibaüzenet!
    a.	Egy véletlen szám (1 és 12 között) alapján
     írasd ki az eredményt!

    """
)

szam=random.randint(1,12)
#szam=rand.randrange(1,13)
print("A generált érték: ", szam)
#szam=int(input("Kérem adjon meg egy számot 1 és 12 között!"))
if szam==1:
    print("január")
elif szam==2:
    print("február")
elif szam==3:
    print("március")
elif szam==4:
    print("április")
elif szam==5:
    print("május")
elif szam==6:
    print("június")
if szam==7:
    print("július")
elif szam==8:
    print("agusztus")
elif szam==9:
    print("szeptember")
elif szam==10:
    print("október")
elif szam==11:
    print("november")
elif szam==12:
    print("december")
#elif szam<1 and szam>12:
#    print("""Hiba: Hibás adatot adott
#     meg a felhasználó!""")