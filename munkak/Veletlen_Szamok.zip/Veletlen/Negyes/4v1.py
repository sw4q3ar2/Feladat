import math
print(
    """
    4.	Kérj be ellenőrzötten egy negatív számot,
     majd add meg az abszolút értékét! (lebegőpontos)
    """
)

szam=float(input("Kérem adjon meg egy negatív számot!"))
#adat ellenörzés
while(szam>=0):
    szam = float(input("HIBA: Kérem adjon meg egy negatív számot!"))
#főprogram
#abszolút érték kiírása
print("|"+str(szam)+"|="+str(math.fabs(szam)))


