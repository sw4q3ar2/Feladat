import math
print(
"""5.	Kérj be ellenőrzötten egy 3-mal osztható,
 kétjegyű számot, majd add meg a négyzetét!"""
)
szam=int(input("Kérlek adj meg egy számot!"))

#ismételt bekérés
#feltétel:
# pozitív ((szam>=10) and (szam<=99) and (szam%3==0))
while(szam<10 or szam>99 or szam%3!=0):
    szam = int(input("Hiba: Kérlek adjon meg egy kétjegyű hárommal osztható számot!"))

#főprogrami rész
print(szam,"*", szam,"=",math.pow(szam,2))