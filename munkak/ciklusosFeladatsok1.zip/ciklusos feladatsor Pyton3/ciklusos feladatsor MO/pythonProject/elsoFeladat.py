#a feladat #hibaüzenetet ad mert negatív számot nem írhatunk be
#for i in range(-6):
#    print(i)

#átírás működőre pl.
print("Teszteld az alábbi eseteket is (tipp, eredmény...):")
print("1.a feladat: ")
for i in range(100,0,-6):
    print(i)

#b feladat #hibaüzenetet ad mert az első paraméter nagyobb a másodiknál
#for j in range(16,6):
#    print(j)

#átírás működőre
print("1.b feladat: ")
for j in range(16,6, -1):
    print(j)

#b feladat #hibaüzenetet ad mert az első paraméter nagyobb a másodiknál
print("1.c feladat: ")
for k in range(16,6,-2):
    print(k)