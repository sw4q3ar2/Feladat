print("3. feladat: Írasd ki a számokat kettesével 20-tól 56-ig! (az 56-ot is!)")
for i in range(20, 57, 2):
    print(i)