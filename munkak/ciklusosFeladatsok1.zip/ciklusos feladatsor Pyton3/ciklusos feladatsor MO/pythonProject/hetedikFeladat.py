print("5. feladat: 7.	Kérj be 2 számot, majd írasd ki a számokat 0-tól a 2 szám szorzatáig!")
szam1=int(input("Kérlek adj meg egy számot!"))
szam2=int(input("Kérlek adj meg egy másik számot!"))

szorzat=szam1*szam2;
#1 verzio for
#print("0-tól a két szám szorzatáig"+str(szorzat)+" a számok:")
#for i in range(0, (szorzat+1)):
#    print(i)

#2.verzió while
print("0-tól a két szám szorzatáig"+str(szorzat)+" a számok:")
n=0
while(n!=(szorzat+1)):
    print(n)
    n+=1 #n=n+1

