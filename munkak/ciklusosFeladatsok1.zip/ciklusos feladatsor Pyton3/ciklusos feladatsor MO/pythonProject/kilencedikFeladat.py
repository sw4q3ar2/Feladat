
print("9. feladat: Írasd ki egy bekért szám faktoriálisának az eredményét!")
#A matematikában egy n nemnegatív egész szám faktoriálisának az n-nél kisebb vagy egyenlő pozitív egész számok szorzatát nevezzük. Jelölése: n!,
#faktoriális sorozat: 1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800, 39916800, 479001600, 6227020800, 87178291200, 1307674368000, 20922789888000, 355687428096000, 6402373705728000, 121645100408832000, 2432902008176640000, …
szam1=int(input("Kérlek adj meg egy számot!"))
print("A "+str(szam1)+"!= ", end=" ")
faktoriális=1
for i in range(1, (szam1+1)):
    faktoriális*=i
print(faktoriális)