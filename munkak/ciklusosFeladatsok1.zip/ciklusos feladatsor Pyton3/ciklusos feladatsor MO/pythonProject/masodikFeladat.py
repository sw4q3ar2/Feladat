print("2. feladat: Írasd ki a számokat egyesével 0-tól 20-ig! (a 20-at is!)")
for i in range(0, 21):
    print(i)

#másik megoldás
print("2B. feladat: ")
for i in range(0, 20):
        print(i)
print(20)


