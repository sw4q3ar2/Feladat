print("4. feladat: Írasd ki a számokat 4-esével 77-től -77-ig! ")
for i in range(77, 77,4):
    print(i)