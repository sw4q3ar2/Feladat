print("8. feladat: Írasd ki az első 7 pozitív egész számot vesszővel elválasztva!")
for i in range(1, 8):
    print(i, end=", ")

print("");
print("8.A:")
for i in range(1, 8):
    if(i<7):
        print(i, end=", ")
    else:
        print(i)