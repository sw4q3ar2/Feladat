print("5. feladat: Kérj be 2 számot, majd írasd ki a számokat a legkisebbtől a legnagyobbig! (a legnagyobbat is!)")
szam1=int(input("Kérlek adj meg egy számot!"))
szam2=int(input("Kérlek adj meg egy másik számot!"))

szorzat=szam1*szam2;
print("0-tól a két szám szorzatáig"+str(szorzat)+" a számok:")
if(szam1<szam2):
    for i in range(szam1, (szorzat+1)):
        print(i)
else:
    for i in range(szam2, (szorzat+1)):
        print(i)