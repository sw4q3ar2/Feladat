
print("10. feladat: Írasd ki 2 bekért szám (x és y) alapján, hogy mennyi 3x+y2!")

szam1=int(input("Kérlek adj meg egy számot!"))
szam2=int(input("Kérlek adj meg másik számot!"))
muvelet=3*szam1+szam2*szam2
print("3*"+str(szam1)+"+"+str(szam2)+"*"+str(szam2)+"= "+str(muvelet))

#művelet kiszámolása más módokon
#muvelet=3*szam1+szam2**2
#muvelet=3*szam1+pow(szam2,2)
