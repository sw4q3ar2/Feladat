print("""11.	Számold meg 2 bekért szám közötti páros számokat!
 (hány db van?)""")

szam1=int(input("Kérlek adj meg egy számot!"))
szam2=int(input("Kérlek adj meg egy másik számot!"))
db=0
seged=0

if szam1>szam2:
    seged=szam1
    szam1=szam2
    szam2=seged

for i in range(szam1, szam2+1):
    if i%2==0:
        db+=1 #db=db+1

print("Páros számok száma: ", db)