print("12. Add össze 10 bekért számnál a negatív számokat!)")

osszeg=0
for i in range(10):
    szam=int(input("Kérlek add meg "+str(i+1)+". számot:"))
    if(szam<0):
        osszeg+=szam
print("A negatív számok összege: ", osszeg)