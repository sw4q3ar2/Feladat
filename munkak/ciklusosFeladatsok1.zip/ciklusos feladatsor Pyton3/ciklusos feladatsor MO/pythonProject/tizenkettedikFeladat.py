print("""11.	Számold meg 2 bekért szám közötti páros számokat!
 (hány db van?)""")
#A háromszög bármely oldalának hossza kisebb a másik két oldal hosszának összegénél.
# Azaz: a<b+c  b<a+c  és c<a+b.

szam1=int(input("Kérlek adj meg egy számot!"))
szam2=int(input("Kérlek adj meg egy másik számot!"))
szam3=int(input("Kérlek adj meg egy harmadik számot!"))

if (szam1+szam2<szam3 or szam1+szam3<szam2 or szam3+szam2<szam1):
        print(" Készíthető belölük háromszög.")
else:
    print("Nem készíthető.")


